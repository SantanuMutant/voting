/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
 
@WebServlet("/registation_1")
public class registation_1 extends HttpServlet {
 
    Connection con;
    PreparedStatement pst;
    PreparedStatement pst1;
    ResultSet rs;
  
 
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
 
        try
        {
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/ebank", "root", "");
            String fname = request.getParameter("fname");
           
            String candidate = request.getParameter("candidate");
            String Eaddress = request.getParameter("Eaddress");
            String voterID = request.getParameter("voterID");
            
            
            pst = con.prepareStatement("insert into voting(fname,candidate,Eaddress,voterID)values(?,?,?,?)");
            pst.setString(1, fname);
            pst.setString(2, candidate);
            pst.setString(3, Eaddress);
            pst.setString(4, voterID);
            pst.executeUpdate();
            
            pst1 = con.prepareStatement("select max(id) from registation_1");
            rs = pst1.executeQuery();
            
            rs.next();
            
            int regno;
            
            regno = rs.getInt(1);
            
            out.println("Thank you for your VOTE");
           out.println("Your VOTING Number is :" + regno);
            
            
        } catch (ClassNotFoundException ex) {
           Logger.getLogger(registation_1.class.getName()).log(Level.SEVERE,null,ex);
        } catch (SQLException ex) {
            Logger.getLogger(registation_1.class.getName()).log(Level.SEVERE,null,ex);
           //ex.printStackTrace();
        }
    }
}